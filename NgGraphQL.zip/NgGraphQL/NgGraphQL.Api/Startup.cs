﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GraphQL.Server.Ui.Voyager;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using NgGraphQL.Api.GraphQLQuery;
using NgGraphQL.Domain.Repository;
using NgGraphQL.Persistence.DataContext;
using NgGraphQL.Persistence.Helpers;
using NgGraphQL.Persistence.Repository;
using NgGraphQL.Service.Services;

namespace NgGraphQL.Api
{
    public class Startup
    {
        public Startup(Microsoft.Extensions.Configuration.IConfiguration configuration)
        {
            Configuration = configuration;
            this.apiConfiguration = Configuration.Get<ApiConfiguration>();
        }

        public Microsoft.Extensions.Configuration.IConfiguration Configuration { get; }
        private readonly ApiConfiguration apiConfiguration;

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllers();
            MongoClientSettings settings = MongoClientSettings.FromConnectionString(Configuration["MongoDbConfiguration:ConnectionString"]);
            services.AddSingleton((s) => new MongoClient(settings));
            settings.ServerApi = new ServerApi(ServerApiVersion.V1);
            var client = new MongoClient(settings);

            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserContext, UserContext>();

            services.AddScoped<IAccountRepository, AccountRepository>();
            services.AddScoped<IAccountContext, AccountContext>();

            services.AddScoped<IBillingAccountRepository, BillingAccountRepository>();
            services.AddScoped<IBillingAccountContext, BillingAccountContext>();

            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IAccountService, AccountService>();
            services.AddScoped<IBillingAccountService, BillingAccountService>();


            //GraphQl
            //services.AddGraphQL();
            services.AddGraphQLServer()
                .AddQueryType<UserQuery>();
                //.AddQueryType<AccountQuery>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGraphQL("/graphql");
                //endpoints.MapGraphQL("/api/graphql");
                //endpoints.MapGraphQL();
                //endpoints.MapControllers();
            });
            app.UseGraphQLVoyager(new VoyagerOptions()
            {
                GraphQLEndPoint = "/api/graphql"

            }, "/grapghql-voyager");
        }
    }
}
