﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HotChocolate;
using NgGraphQL.Domain.Core;
using NgGraphQL.Domain.Repository;

namespace NgGraphQL.Api.GraphQLQuery
{
    public class AccountQuery
    {
        //Gets all Account listing
        public async Task<IEnumerable<Account>> AllAccountListing([Service] IAccountService accountService)
        {
            return await accountService.GetAllAccountAsync();
        }
    }
}
