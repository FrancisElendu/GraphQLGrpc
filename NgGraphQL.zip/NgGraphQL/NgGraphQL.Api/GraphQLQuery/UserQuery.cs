﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HotChocolate;
using NgGraphQL.Domain.Core;
using NgGraphQL.Domain.Repository;

namespace NgGraphQL.Api.GraphQLQuery
{
    public class UserQuery
    {
        //Gets all User listing
        public async Task<IEnumerable<User>> GetAllUsers([Service] IUserService userService)
        {
            return await userService.GetAllUserAsync();
        }

        //Gets all Account listing
        public async Task<IEnumerable<Account>> AllAccountListing([Service] IAccountService accountService)
        {
            return await accountService.GetAllAccountAsync();
        }


        //Gets Account listing bt user id
        public async Task<IEnumerable<Account>> AccountListingByUserId(string userId, [Service] IAccountService accountService)
        {
            return await accountService.GetUserAccountaByIdAsync(userId);
        }

        //Gets Billing Account listing bt user id
        public async Task<IEnumerable<BAccount>> BillingAccountListByUserId(string userId, [Service] IBillingAccountService billingAccountService)
        {
            return await billingAccountService.GetBillingAccountsByUserIdAsync(userId);
        }
    }
}
