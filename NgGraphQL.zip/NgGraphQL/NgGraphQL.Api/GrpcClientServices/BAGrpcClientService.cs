﻿using System;
using BillingAccount.Grpc.Protos;

namespace NgGraphQL.Api.GrpcClientServices
{
    public class BAGrpcClientService
    {
        private readonly BAccountProtoService.BAccountProtoServiceClient _bAccountProtoService;
        public BAGrpcClientService(BAccountProtoService.BAccountProtoServiceClient bAccountProtoService)
        {
            _bAccountProtoService = bAccountProtoService;
        }


        //create a method to get the data
        //set up the GetBAccountRequest
        //make the call using _bAccountProtoService
        //public async Task<IEnumerable<>>
    }
}
