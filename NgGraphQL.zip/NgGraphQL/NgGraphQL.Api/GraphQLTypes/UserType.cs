﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HotChocolate;
using HotChocolate.Types;
using NgGraphQL.Domain.Core;
using NgGraphQL.Domain.Repository;

namespace NgGraphQL.Api.GraphQLTypes
{
    public class UserType : ObjectType<User>
    {
        protected override void Configure(IObjectTypeDescriptor<User> descriptor)
        {
            base.Configure(descriptor);
            descriptor.Description("Represents User bounded context");

            descriptor.Field(p => p.Id).Ignore();  //this will ignore the user guid id

            descriptor
                .Field(p => p.Accounts)
                .ResolveWith<Resolvers>(p => p.GetUserAccountsByUserId(default!, default!));
        }

        private class Resolvers
        {
            public async Task<IEnumerable<Account>> GetUserAccountsByUserId(User user, [Service] IAccountService accountService)
            {
                var result = await accountService.GetAllAccountAsync();

                var filteredResult = result.Where(x => x.CurrentUserId == user.Id);

                return filteredResult;
            }
        }

    }
}
