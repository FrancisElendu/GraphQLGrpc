﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NgGraphQL.Domain.Core;
using NgGraphQL.Domain.Repository;

namespace NgGraphQL.Api.Controllers
{
    [ApiController]
    [Route("api/account")]
    public class AccountController : ControllerBase
    {
        //private readonly IAccountRepository _accountRepository;
        private readonly IAccountService _accountService;
        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        [HttpGet]
        public async Task<IEnumerable<Account>> GetAllAccount()
        {
            return await _accountService.GetAllAccountAsync();
        }
    }
}
