﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NgGraphQL.Domain.Core;
using NgGraphQL.Domain.Repository;
using NgGraphQL.Persistence.Repository;

namespace NgGraphQL.Api.Controllers
{
    [ApiController]
    [Route("api/user")]
    public class UserController : ControllerBase
    {
        //private readonly IUserRepository _userRepository;
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public async Task<IEnumerable<User>> GetAllUser()
        {
            return await _userService.GetAllUserAsync();
        }
    }
}
