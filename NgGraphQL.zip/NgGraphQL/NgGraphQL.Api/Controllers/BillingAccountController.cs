﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NgGraphQL.Domain.Core;
using NgGraphQL.Domain.Repository;

namespace NgGraphQL.Api.Controllers
{
    [ApiController]
    [Route("api/billingaccount")]
    public class BillingAccountController : ControllerBase
    {
        //private readonly IBillingAccountRepository _billingAccountRepository;
        private readonly IBillingAccountService _billingAccountService;
        public BillingAccountController(IBillingAccountService billingAccountService)
        {
            _billingAccountService = billingAccountService;
        }

        [HttpGet]
        public async Task<IEnumerable<BAccount>> GetAllBillingAccount()
        {
            return await _billingAccountService.GetAllBillingAccountAsync();
        }
    }
}
